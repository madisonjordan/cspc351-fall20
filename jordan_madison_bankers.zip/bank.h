//
//  bank.h
//  bankers
//
//  Created by William McCarthy on 1011//20.
//

#ifndef bank_h
#define bank_h

#include "ext_vector.h"
#include "customer.h"
#include <queue>

class Bank
{
public:
  //Bank() = default;
  Bank(const ext_vector<int> &available) : avail(available), customers() {}

  ext_vector<int> get_avail() const { return avail; }

  bool is_avail(const ext_vector<int> &req) const { return req < avail; }

  bool is_safe(int id, const ext_vector<int> &req)
  {
    if (is_avail(req))
      return false;
    if (id > customers.size())
    {
      std::cerr << "WARNING: id out of bounds\n";
      return false;
    }
    Customer *cust = customers[id];
    if (cust->need_exceeded(req))
    {
      return false;
    }

    ext_vector<int> avail_bak = avail;

    std::queue<int> qsafe;
    std::queue<Customer *> qcustomers;

    for (Customer *c : customers)
    {
      if ((cust != c) && !c->needs_met())
      {
        qcustomers.push(c);
      }
    }
    withdraw_resources(req);

    ext_vector<int> max_req;
    bool one_allocated = true;

    while (!qcustomers.empty() && one_allocated)
    {
      one_allocated = false;
      Customer *c = qcustomers.front();
      qcustomers.pop();

      max_req = c->get_max();
      if (is_avail(max_req))
      {
        deposit_resources(max_req);
        qsafe.push(c->get_id());
        one_allocated = true;
      }
      else
      {
        qcustomers.push(c);
      }
    }

    avail = avail_bak;
    return qcustomers.empty();
  }

  bool
  req_approved(int id, const ext_vector<int> &req)
  {
    if (customers[id]->needs_met() == false)
    {
      show();
      return is_avail(req) && is_safe(id, req);
    }
    return false;
  }

  void add_customer(Customer *c) { customers.push_back(c); }

  void withdraw_resources(const ext_vector<int> &req)
  {
    if (!is_avail(req))
    {
      std::cerr << "WARNING: req: " << req << " is not available for withdrawing\n";
      return;
    }
    if (is_avail(req))
    {
      avail -= req;
    }
  }

  void deposit_resources(const ext_vector<int> &req) { avail += req; }

  ext_vector<Customer *> get_customers() const { return customers; }

  void show() const
  {
    std::cout << "avail: [" << avail << "]\n";
    for (Customer *c : customers)
    {
      c->show();
    }
  }

  friend std::ostream &operator<<(std::ostream &os, const Bank &bank)
  {
    bank.show();
    return os;
  }

private:
  ext_vector<int> avail;
  ext_vector<Customer *> customers;
};

#endif /* bank_h */
